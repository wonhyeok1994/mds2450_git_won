/*
 * =====================================================================
 * NAME         : Main.c
 *
 * Descriptions : Main routine for S3C2450
 *
 * IDE          : GCC-4.1.0
 *
 * Modification
 *	  
 * =====================================================================
 */
#include "2450addr.h"
#include "Images/scape.h"
#include "my_lib.h"
#include "option.h"

#define NonPal_Fb   ((volatile unsigned short(*)[480]) FRAME_BUFFER)

#define EXAMPLE 102
  /***************************************
 * 
 * �ǽ� 100 : Sum of Decimal Test
 *
 * �ǽ� 101 : Testing MES Test
 *	
 * �ǽ� 102 : LED Test
 *
 * �ǽ� 103 : Timer Test
 * 
 ***************************************/

void Main(void)
{	
	
	Uart_Init(115200);	
	Uart_Send_Byte('\n');

#if EXAMPLE == 100
	/* Sum of Decimal Test */
{
	int start, end, sum;
	start = 1;
	end = 100;

	Uart_Printf("Start sum of decimal test\n");
	
	sum = SUM_OF_DEC(start,end);
	Uart_Printf("ASM : Sum from %d to %d is [%d]\n",start,end,sum);

	sum = 0;
	for (start=1;start<=end;start++) {
		sum += start;
	}
	Uart_Printf("C   : Sum from %d to %d is [%d]\n",1,end,sum);
}
#endif

	
#if EXAMPLE == 101
	/* Testing MES Test */
{
	
	int a=30;
	int b=18;
	int mes;
	Uart_Printf("\n*** Test GRT_COM_MES ***\n");
	mes = GRT_COM_MES(a,b);
	Uart_Printf("MES = %d \n", mes); 
}
#endif 

#if EXAMPLE == 102 /* LED Test */
	int a;
	
	Led_Init();
	
	while(1){
	/*
	for(a=1;a<5;a++)
		Led_Display(a);	
	*/
	}

#endif

#if EXAMPLE == 103

	Timer_Init();	
	while(1)
	{
		Uart_Send_String("Time Delay\n");
		Timer_Delay(1000);
	}

#endif

#if 0 /* Timer Interrupt */

  Timer_Init();
  Timer_Int_Init();

#endif

#if 1 /* LCD Test */

	int i,j=0;
	
	Lcd_Port_Init();
	NonPal_Lcd_Init();
	
	for(j=0; j<272; j++)
	{
		for(i=0; i<480; i++)
		{
			NonPal_Put_Pixel(i,j,BLUE);
		}
	}
	Uart_Send_String("Hello...!!!\n");		
	Lcd_Draw_BMP(0, 0, scape);
	 
#endif
}	
