#include "2450addr.h"
#include "option.h"

#define EXAMPLE 610

/*********** 6�� Exam ***************	
 * 
 * 610 : Touch Test (�ǽ� 9-1 : Touch Test)
 * 
 * 
 * Advanced Course
 * 1. make macro function 
 */
 
#if EXAMPLE == 610
//**ISR Declaration
void Touch_ISR(void) __attribute__ ((interrupt ("IRQ")));

volatile  int ADC_x, ADC_y;
volatile  int Touch_Pressed=0;

void Touch_ISR()
{
	/* ���ͷ�Ʈ ������� ���� on Touch */
	rINTSUBMSK |= (0x1<<9);
	rINTMSK1 |= (0x1<<31);	
	
	/* TO DO: Pendng Clear on Touch */	
	rSUBSRCPND |= (0x1<<9);
	rSRCPND1 |= (0x1<<31);
	rINTPND1 |= (0x1<<31);

	if(rADCTSC & 0x100)
	{
		rADCTSC &= (0xff); 
		Touch_Pressed = 0;
		Uart_Send_String("Detect Stylus Up Interrupt Signal \n");
	}
	
	else
	{
		Uart_Send_String(" ISR ����  \n");
		
		rADCTSC &=~(0x1<<8);				//detect stylus down
		rADCTSC &= ~(0x1<<7);				//set bit for x position measurement
		rADCTSC |= (0x1<<6);				//YM=Hi-z, YP=Hi-z
		rADCTSC |= (0x1<<5);		
		rADCTSC &= ~(0x1<<4);				//XM=VSS,XP=VDD
		rADCTSC &= ~(0x1<<3);				//pull-up EN
		rADCTSC &= ~(0x1<<2);				//Normal-ADC
		rADCTSC &= ~(0x3);
		rADCTSC |= (0x1);					//X-position = 1


		/* TO DO : ENABLE_START */		
		rADCCON |= (0x1);
		
		/* wait until End of A/D Conversion */
		while(!(rADCCON & (1<<15)));
		rADCCON &= ~(0x1);					//Stop Conversion

		/*Set ADCTSC reg for Y Conversion*/ 
		ADC_x = (rADCDAT0 & 0x3ff);			//Store X value
		
		rADCTSC |= (0x1<<7);				//YM=VSS, YP=VDD
		rADCTSC &= ~(0x1<<6);
		rADCTSC &= ~(0x1<<5);				//XM=Hi-z, XP=Hi-z
		rADCTSC |= (0x1<<4);
		/* clear and then set  ADCTSC [1:0] for Y Conversion*/
		rADCTSC &= ~(0x3);
		rADCTSC |= (0x2);
	
		rADCCON |= (0x1);				//StartConversion
		while(!(rADCCON & (1<<15)));	//wait untill End of A/D Conversion

		ADC_y = (rADCDAT1 & 0x3ff);		//Store y value
		
		Touch_Pressed = 1;
		
		/* TO DO : change to Waiting for interrupt mode 
		 *		   Stylus Up, YM_out Enable, YP_out Disable, XM_out Disable, XP_out disable
		 */
		rADCTSC |= (0x1<<8);
		rADCTSC |= (0x1<<7);
		rADCTSC |= (0x1<<6);
		rADCTSC &= ~(0x1<<5);
		rADCTSC |= (0x1<<4);
		rADCTSC &= ~(0x1<<3);
		rADCTSC &= ~(0x1<<2);
		rADCTSC |= (0x1<<1);
		rADCTSC |= (0x1);
			 
	}
	
	/* ���ͷ�Ʈ �ٽ� ���  on Touch */
	rINTSUBMSK &= ~(0x1<<9);
	rINTMSK1 &= ~(0x1<<31);
	
}

void Main(void)
{	
	Uart_Init(115200);
	Touch_Init();	
	
	Uart_Printf("*** Touch Test *** \n");
	
	/* TO DO : ���ͷ�Ʈ ���Ϳ� Touch_ISR �Լ� ��� */
	pISR_ADC = (unsigned int)Touch_ISR;
	
	/* TO DO :  ���ͷ�Ʈ ��� on Touch */
	rINTSUBMSK &= ~(0x1<<9);
	rINTMSK1 &= ~(0x1<<31);	
	
	while(1)
	{
		if(Touch_Pressed)
		{
			Uart_Printf("X : %d, Y: %d \n", ADC_x, ADC_y);	
		}
	}
}

#endif 
