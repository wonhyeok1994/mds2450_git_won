/***************************************************************
*
*	1. System Init Test 
* 
*	Created by MDS Tech. NT Div.(2Gr) (2015.10.30)
*
****************************************************************
*/

#include "2450addr.h"

void LED_Port_Init(void);
void LED_ON_Off(void);

void Main()
{
	int i=0;
	LED_Port_Init();
	for(i=0; i<5; i++){
		LED_ON_Off();
	}
}

void LED_Port_Init() 
{
  rGPGDAT &= ~(0xf<<4);
  rGPGCON |= (0x55<<10);
}


void LED_ON_Off()
{
  int i;
  rGPGDAT |= (0xf<<4);
  for(i=0;i<0xfffff;i++){}
  rGPGDAT &= ~(0xf<<4);
  for(i=0;i<0xfffff; i++){}
}
